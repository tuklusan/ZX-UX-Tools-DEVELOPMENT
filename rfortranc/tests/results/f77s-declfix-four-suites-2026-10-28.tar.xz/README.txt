F77S strict/source SDK real ZX-UX regression evidence, 2026-10-28
All original JSONs are byte-exact in this .tar.xz, with complete per-case
commands, stdout/stderr, image SHA256 and expected-vs-observed output.
Run tar -xJf <archive> then inspect manifest.json and JSON reports.
No physical 48K Spectrum or full ANSI conformance is asserted.
